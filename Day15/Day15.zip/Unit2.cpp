#include "Unit2.h"



Unit2::Unit2()
{
}


Unit2::~Unit2()
{
}
