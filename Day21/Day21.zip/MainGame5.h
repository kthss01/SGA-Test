#pragma once
class MainGame5
{
public:
	MainGame5();
	~MainGame5();
};

