#include "Unit.h"



Unit::Unit()
{
}


Unit::~Unit()
{
}

void Unit::Move()
{
	cout << "Unit�� Move() ȣ��" << endl;
}

void Unit::Attack()
{
	cout << "Unit�� Attack() ȣ��" << endl;
}
